// BUCKET=s3-html-upload ACCESS_KEY_ID=AKIATOYXF4Y4VBJUTV6E  SECRET_ACCESS_KEY=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 node app.js
const express = require('express');
const app = express();
var AWS = require("aws-sdk");
var path = require('path');
var bodyParser = require("body-parser");
var moment = require('moment');
const HTTP_PORT = 3000;

var ACCESSKEY_ID, SECRETACCESS_KEY, SESSION_TOKEN, KMSKey, credentials;
console.log("envvvvv", process.env.PORT);


const S3Service = new AWS.S3({signatureVersion: "v4"});

var BUCKET = process.env.BUCKET || 's3-html-upload';
var ACCESS_KEY_ID = process.env.ACCESS_KEY_ID || 'AKIATOYXF4Y4VBJUTV6E';
var SECRET_ACCESS_KEY = process.env.SECRET_ACCESS_KEY || '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';
var KMSKey = 'e1edc87-d67a-4cf3-bc27-1995d19e5c8d';

var bucket = new AWS.S3({
	accessKeyId: ACCESS_KEY_ID,
	secretAccessKey: SECRET_ACCESS_KEY,
	signatureVersion: "v4"
});


app.use(bodyParser.json() );       // to support JSON-encoded bodies
app.use(bodyParser.urlencoded({     // to support URL-encoded bodies
  extended: true
}));

app.get("/putObjectS3", function(request, response){
	response.send("Test put object S3");
});

// viewed at http://localhost:3000
app.get('/', function(req, res) {
    res.sendFile(path.join(__dirname + '/index.html'));
});

app.post("/putObjectS3", function(request, response){
	var data = request.body;
	console.log('data- ', data);
	var { resource } = data;

	var path = resource + "/" + resource + '-' + data.team + "-" + moment().format('MM-DD-YYYY') + ".json";
	var params = {
		Bucket: BUCKET,
		Key: path,
		ContentType: 'application/json',
		Body: JSON.stringify(data, null, 4),
		ACL: 'public-read',
		// SSEKMSKeyId: KMSKey,
		ServerSideEncryption: 'aws:kms'
	};

	bucket.upload(params, function(err, res) {
		if (err) {
			console.log('e- ', err);
			response.send(JSON.stringify(err));
		} else {
			console.log('res- ', res);
			response.send(JSON.stringify(res));
		}
	});
});

app.listen(HTTP_PORT, () => console.log('...WWW Node Server listening on port ' + HTTP_PORT + '!'));
